<!DOCTYPE html>

<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta name="description" content="Photo Album - Upload Photo" />
        <meta name="keywords" content="photo, album, uploader" />
        <meta name="author" content="Chris Rickard" />
        <title>Photo Album - Upload Photo</title>
        <link href="styles/style.css" rel="stylesheet">


    </head>

    <body>

        <h1>Photo Album</h1>
        <h3>Student ID: 6512178</h3>
        <h3>Name: Christopher Rickard</h3>

        <br>

        <img src="img/photo.jpg" width="800">

        <br>
        <br>

        <a href="upload.php">Photo Uploader</a>

    </body>

</html>